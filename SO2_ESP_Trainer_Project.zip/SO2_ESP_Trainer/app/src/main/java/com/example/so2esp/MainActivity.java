package com.example.so2esp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(17,19,24));
        getWindow().setNavigationBarColor(Color.rgb(17,19,24));
        setContentView(new TrainerView());
    }

    class TrainerView extends View {
        Paint p = new Paint(3);
        boolean showBoxes = true, showDistance = true, showNames = true;
        int tick = 0;
        Random random = new Random(7);
        TrainerView() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }

        void paintText(Canvas c, String s, float x, float y, int color, float size, boolean bold) {
            p.setColor(color); p.setTextSize(size); p.setTypeface(bold ? Typeface.create("sans-serif",1) : Typeface.create("sans-serif",0));
            p.setStyle(Paint.Style.FILL); c.drawText(s,x,y,p);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(18,21,27));
            // Training arena background
            p.setColor(Color.rgb(34,40,49)); p.setStyle(Paint.Style.FILL);
            c.drawRect(0,h*.72f,w,h,p);
            p.setColor(Color.rgb(51,60,72)); p.setStrokeWidth(2); p.setStyle(Paint.Style.STROKE);
            for(int i=0;i<8;i++) c.drawLine(i*w/7f,h*.72f,w/2f+(i-w/3.5f)*w*.10f,h*.30f,p);
            c.drawLine(0,h*.72f,w,h*.72f,p);
            p.setStyle(Paint.Style.FILL);
            // Walls and obstacles
            p.setColor(Color.rgb(76,84,96)); c.drawRoundRect(w*.35f,h*.30f,w*.65f,h*.76f,8,8,p);
            p.setColor(Color.rgb(95,105,118)); c.drawRect(w*.35f,h*.30f,w*.65f,h*.35f,p);
            paintText(c,"УЧЕБНОЕ УКРЫТИЕ",w*.385f,h*.48f,Color.WHITE,14,true);

            // Simulated targets, deliberately drawn over the wall to demonstrate x-ray training overlay.
            float[][] targets={{.22f,.52f},{.50f,.55f},{.78f,.48f}};
            String[] names={"BOT-01","BOT-02","BOT-03"};
            int[] ds={12,18,24};
            for(int i=0;i<targets.length;i++){
                float x=w*targets[i][0], y=h*targets[i][1], bw=w*.055f, bh=h*.25f;
                int col = i==1 ? Color.rgb(255,190,65) : Color.rgb(75,225,145);
                if(showBoxes){
                    p.setColor(col); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
                    c.drawRoundRect(x-bw/2,y-bh/2,x+bw/2,y+bh/2,5,5,p);
                    p.setStyle(Paint.Style.FILL);
                    c.drawCircle(x,y-bh*.62f,bw*.24f,p);
                    c.drawLine(x,y-bh*.38f,x,y+bh*.34f,p);
                    c.drawLine(x-bw*.28f,y-bh*.12f,x+bw*.28f,y-bh*.12f,p);
                    c.drawLine(x,y+bh*.34f,x-bw*.22f,y+bh*.55f,p);
                    c.drawLine(x,y+bh*.34f,x+bw*.22f,y+bh*.55f,p);
                }
                if(showNames) paintText(c,names[i],x-bw*.75f,y-bh*.62f-9,col,13,true);
                if(showDistance) paintText(c,ds[i]+" м",x-bw*.35f,y+bh*.68f,Color.WHITE,12,false);
            }
            // HUD
            p.setColor(0xdd101319); c.drawRoundRect(18,16,270,83,14,14,p);
            paintText(c,"SO2 ESP TRAINER",32,43,Color.rgb(255,75,75),18,true);
            paintText(c,"СИМУЛЯЦИЯ · НЕ ПОДКЛЮЧЕНА К ИГРЕ",32,64,Color.LTGRAY,10,true);
            p.setColor(0xdd101319); c.drawRoundRect(w-190,16,w-18,68,12,12,p);
            paintText(c,"ЦЕЛИ: 3",w-172,39,Color.WHITE,14,true);
            paintText(c,"СКВОЗЬ УКРЫТИЕ: ON",w-172,56,Color.rgb(75,225,145),10,true);

            // center reticle
            p.setColor(Color.WHITE); p.setStrokeWidth(2);
            c.drawLine(w/2-10,h*.88f,w/2+10,h*.88f,p);
            c.drawLine(w/2,h*.88f-10,w/2,h*.88f+10,p);

            // bottom controls
            p.setColor(0xdd101319); c.drawRoundRect(18,h-58, w-18,h-14,12,12,p);
            paintText(c,"Нажми на экран: сменить расположение учебных ботов",34,h-31,Color.WHITE,13,false);
            tick++;
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_UP){ invalidate(); return true; }
            return true;
        }
    }
}
